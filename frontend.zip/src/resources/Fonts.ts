const editorFonts: string[] = [
    "Anonymous Pro",
    "Cousine",
    "Fira Code",
    "Inconsolata",
    "JetBrains Mono",
    "Jura",
    "Roboto Mono",
    "Source Code Pro",
    "Space Mono",
    "Ubuntu Mono",
]

export { editorFonts }
